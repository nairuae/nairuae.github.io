'use strict';

import {initFeedbackSlider} from './modules/slider';

document.addEventListener('DOMContentLoaded', () => {
    initFeedbackSlider();
})