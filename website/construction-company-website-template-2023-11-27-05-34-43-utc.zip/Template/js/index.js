'use strict';

import drawHotspots from "./modules/spots";

document.addEventListener('DOMContentLoaded', () => {
    drawHotspots();
})