'use strict';

import {initProgressbar} from './modules/effects';

document.addEventListener('DOMContentLoaded', () => {
    initProgressbar();
})