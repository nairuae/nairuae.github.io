Thank you for purchasing our product! We appreciate your support and are confident that you will be satisfied with your purchase. We hope you are satisfied with your purchase and look forward to serving you again in the future.

If you have any questions or concerns, please don't hesitate to reach out to us. We are here to help and want to make sure that you are completely satisfied with your purchase. 

Thank you again for choosing our product.


Best Regrads,


Gholib Tammami