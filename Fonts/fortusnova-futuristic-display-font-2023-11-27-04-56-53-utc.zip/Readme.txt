Hello There!
Thankyou for purchasing and using CF Fortusnova font. 

|| Please  you must abide the user agreement license || 

If there is a problem, question, or anything about our fonts, please send us an email to
creatifont.std@gmail.com

Fortusnova is a inktrap cut that inspired from a futuristic sharp modern vibes. Fortusnova comes in various wight and style font

2023. Copyright by Creatifont Studio. All rights reserved. 

If you want a custom license, freely to contact us at 
Creatifont.std@gmail.com

Thanks,

Creatifont Studio