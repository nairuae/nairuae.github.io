Renava Serif is a balanced, smooth, elegant and stylish serif font. He has a beautiful character. It fits perfectly with invitation card designs, company logos, movie titles, movie names, business cards, book titles, brand names and various other designs. Renava Serif is a subtle serif font that exudes sophistication and elegance. Its stylish alternations and ligatures make this font the perfect partner for any project.

FEATURE :
- TTF/OTF
- WOFF/WOFF2
- Ligature
- Uppercase and lowercase
- Numbering and Punctuation
- Works on PC or Mac
- Simple Installation
- Supports Adobe Illustrator, Adobe Photoshop, Adobe InDesign, also works in Microsoft Word

Hope you like it.
Thank you.